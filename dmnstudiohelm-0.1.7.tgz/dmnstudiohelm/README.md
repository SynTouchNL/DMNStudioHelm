
# Introduction
This chart is maintained by SynTouch.
For chart changes, contact Jan Brekelmans.

# Publishing chart
TODO: Move to pipeline (Something like https://gist.github.com/joaomlneto/b3970c9f022f231c2bbf644a780ebe12)
For now:
```
helm package .
helm repo index .
git commit ....
```

# Using chart:
For the Operaton instance used for testing, build a version of Operaton that includes the Operaton Keycloak JAR.
See https://github.com/SynTouchNL/dmn-operaton-helm for more information.

```
helm repo add dmnstudio 'https://raw.githubusercontent.com/SynTouchNL/DMNStudioHelm/main'
helm repo update
helm search repo dmnstudio/dmnstudiohelm
```

// TODO
`helm install --dependency-update dmnstudio ./ --namespace dmn -f ./myvalues.yaml`

# Configuration
## Prerequisites
- A database for the application (the application is tested with PostgreSQL)
- Keycloak installed with a client configured for dmnstudio (One for frontend and one for backend)
- Operaton instances to deploy

## Secrets
The chart supports Azure Key Vault (AKV) secrets. Use this feature or ensure the secret for DMN Studio is already in place.
The secret file should contain these secrets:
```
QUARKUS_DATASOURCE_PASSWORD
QUARKUS_OIDC_CREDENTIALS_SECRET
QUARKUS_OPENAPI_GENERATOR_OPERATON_REST_API_JSON_AUTH_BASIC_AUTH_PASSWORD
OPERATON_KEYCLOAK_CLIENT_SECRET
```

## Licensing
Copyright © 2026 SynTouch B.V.

This project is licensed under the European Union Public Licence (EUPL) Version 1.2 or later — see the [LICENSE](LICENSE) file for details.